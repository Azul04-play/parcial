<?php
require_once 'app/classes/Core.php'; 
Core::run(); // Ejecuta el método estático run() de la clase Core
?>