<?php

// Modelo para manejar las operaciones de la tabla todos
class todoModel extends Model {
    
    // Nombre de la tabla en la base de datos
    protected $table = 'todos';
    
    // ATENCIÓN: Actualizar 'fillable' para usar los IDs normalizados
    protected $fillable = ['task', 'description', 'id_prioridad', 'id_estado'];
    
    // IDs de estado constantes para usar en el modelo (ajustar si tus IDs son diferentes)
    const ESTADO_COMPLETADA = 3;
    const ESTADO_PENDIENTE = 1;

    /**
     * Función auxiliar interna para procesar tareas y añadir detalles de vista (color, texto, fecha).
     * @param array $todos Array de tareas a procesar
     * @return array
     */
    private static function processTodos(array $todos) {
        foreach ($todos as &$todo) {
            // Se asume que getPriorityText/Color son métodos de alguna clase Todo o Helpers
            $todo['priority_text'] = Todo::getPriorityText($todo['nombre_prioridad']);
            $todo['priority_color'] = Todo::getPriorityColor($todo['nombre_prioridad']);
            $todo['formatted_date'] = date('d/m/Y H:i', strtotime($todo['created_at']));
            
            // Cargar las categorías asociadas si la lógica existe
            // $todo['categorias'] = categoriaModel::getByTodoId($todo['id']); 
        }
        return $todos;
    }
    
    /**
     * Obtener todas las tareas con información adicional, ESTADO, PRIORIDAD Y CATEGORÍAS
     * Implementa la lógica de filtrado por Estado y Prioridad.
     *
     * @param array $filters Array asociativo con filtros (ej: ['filter_estado' => 1, 'filter_prioridad' => 3])
     * @return array Array de tareas con datos procesados
     */
    public static function getAllWithDetails(array $filters = []) {
        $where_clauses = [];
        $params = [];

        // 1. Construir cláusulas WHERE basadas en los filtros
        if (isset($filters['filter_estado']) && is_numeric($filters['filter_estado'])) {
            $where_clauses[] = "t.id_estado = ?";
            $params[] = $filters['filter_estado'];
        }

        if (isset($filters['filter_prioridad']) && is_numeric($filters['filter_prioridad'])) {
            $where_clauses[] = "t.id_prioridad = ?";
            $params[] = $filters['filter_prioridad'];
        }

        // 2. Definir la cláusula WHERE y la consulta base
        $where_sql = count($where_clauses) > 0 ? " WHERE " . implode(" AND ", $where_clauses) : "";

        $sql = "
            SELECT 
                t.*, 
                e.nombre_estado, 
                p.nombre_prioridad
            FROM todos t
            INNER JOIN estados e ON t.id_estado = e.id_estado
            INNER JOIN prioridades p ON t.id_prioridad = p.id_prioridad
            {$where_sql}
            ORDER BY t.created_at DESC
        ";
        
        $result = Db::query($sql, $params);
        $todos = $result->fetchAll();
        
        // 3. Procesar y devolver
        return self::processTodos($todos);
    }
    
    /**
     * Obtener tareas completadas
     * ATENCIÓN: Usamos id_estado = self::ESTADO_COMPLETADA
     * @return array Array de tareas completadas
     */
    public static function getCompleted() {
        // Mejoramos la consulta para que también traiga el nombre de la prioridad
        $sql = "
            SELECT 
                t.*, e.nombre_estado, p.nombre_prioridad 
            FROM todos t 
            INNER JOIN estados e ON t.id_estado = e.id_estado
            INNER JOIN prioridades p ON t.id_prioridad = p.id_prioridad
            WHERE t.id_estado = ? 
            ORDER BY t.updated_at DESC
        ";
        $result = Db::query($sql, [self::ESTADO_COMPLETADA]);
        $todos = $result->fetchAll();
        // [CORREGIDO] Aplicar procesamiento de datos
        return self::processTodos($todos);
    }
    
    /**
     * Obtener tareas pendientes
     * ATENCIÓN: Usamos id_estado = self::ESTADO_PENDIENTE
     * @return array Array de tareas pendientes
     */
    public static function getPending() {
         // Mejoramos la consulta para que también traiga el nombre de la prioridad
        $sql = "
            SELECT 
                t.*, e.nombre_estado, p.nombre_prioridad 
            FROM todos t 
            INNER JOIN estados e ON t.id_estado = e.id_estado
            INNER JOIN prioridades p ON t.id_prioridad = p.id_prioridad
            WHERE t.id_estado = ? 
            ORDER BY t.id_prioridad DESC, t.created_at ASC
        ";
        $result = Db::query($sql, [self::ESTADO_PENDIENTE]);
        $todos = $result->fetchAll();
        // [CORREGIDO] Aplicar procesamiento de datos
        return self::processTodos($todos);
    }
    
    /**
     * Buscar tareas por texto
     * @param string $search Texto a buscar
     * @return array Array de tareas encontradas
     */
    public static function search($search) {
        $sql = "
            SELECT 
                t.*, e.nombre_estado, p.nombre_prioridad
            FROM todos t 
            INNER JOIN estados e ON t.id_estado = e.id_estado
            INNER JOIN prioridades p ON t.id_prioridad = p.id_prioridad
            WHERE t.task LIKE ? OR t.description LIKE ? 
            ORDER BY t.created_at DESC
        ";
        $searchTerm = "%{$search}%";
        $result = Db::query($sql, [$searchTerm, $searchTerm]);
        $todos = $result->fetchAll();
        // [CORREGIDO] Aplicar procesamiento de datos
        return self::processTodos($todos);
    }
    
    // Asegúrate de que tu clase base (Model) maneje estas funciones,
    // o inclúyelas aquí: find, create, update, delete.
} // <-- Esta llave cierra la clase todoModel
?>