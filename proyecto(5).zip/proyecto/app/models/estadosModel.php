<?php

class estadosModel extends Model {

    // Nombre de la tabla
    protected $table = 'estados';

    // Campos que se pueden llenar masivamente
    protected $fillable = ['nombre_estado', 'descripcion'];

    /**
     * Obtener todos los estados
     */
    public static function all() {
        $sql = "SELECT * FROM estados ORDER BY id_estado ASC";
        $result = Db::query($sql);
        return $result->fetchAll();
    }

    /**
     * Buscar un estado por ID
     */
    public static function find($id_estado) {
        $sql = "SELECT * FROM estados WHERE id_estado = ? LIMIT 1";
        $result = Db::query($sql, [$id_estado]);
        return $result->fetch();
    }

    /**
     * Crear un nuevo estado
     */
    public static function create($data) {
        return parent::create($data);
    }

    /**
     * Actualizar un estado por ID
     */
    public static function update($id_estado, $data) {
        return parent::update($id_estado, $data, 'id_estado');
    }

    /**
     * Eliminar un estado por ID
     */
    public static function delete($id_estado) {
        return parent::delete($id_estado, 'id_estado');
    }

    /**
     * Buscar estados por nombre o descripción
     */
    public static function search($search) {
        $sql = "
            SELECT * FROM estados
            WHERE nombre_estado LIKE ? OR descripcion LIKE ?
            ORDER BY id_estado ASC
        ";
        $searchTerm = "%{$search}%";
        $result = Db::query($sql, [$searchTerm, $searchTerm]);
        return $result->fetchAll();
    }
}

?>
