<?php

class Core {
   
    // 🔹 Propiedades del framework
    private $framework = 'Core Framework';
    private $version = '1.0.0';
    private $uri = [];
   
    // 🔹 Método constructor
    public function __construct() {
        $this->init();
    }  

    /**
     * Inicializa el sistema
     */
    private function init() {
        $this->init_session();
        $this->init_load_config();
        $this->init_load_functions();
        $this->init_autoload();
        $this->dispatch();
    }
   
    private function init_session() {
        if(session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }
   
    private function init_load_config() {
        $file = 'core_config.php';
        if(!is_file('app/config/'.$file)) {
            die(sprintf(
                'El archivo %s no se encuentra, es requerido para que %s funcione.', 
                $file, 
                $this->framework
            ));
        }
        require_once 'app/config/'.$file;
    }

    private function init_load_functions() {
        $basic = 'core_basic_functions.php';
        $custom = 'core_custom_functions.php';
        if(!is_file(FUNCTIONS.$basic) || !is_file(FUNCTIONS.$custom)) {
            die(sprintf('Los archivos de funciones no se encuentran, son requeridos para que %s funcione.', $this->framework));
        }
        require_once FUNCTIONS.$basic;
        require_once FUNCTIONS.$custom;
    }

    private function init_autoload() {
        require_once CLASSES . 'Autoloader.php';
        Autoloader::init();
    }

    private function filter_url() {
        if(isset($_GET['uri'])) {
            $this->uri = $_GET['uri'];
            $this->uri = rtrim($this->uri, '/');
            $this->uri = strtolower($this->uri);
            $this->uri = filter_var($this->uri, FILTER_SANITIZE_URL);
            $this->uri = explode('/', $this->uri);
        } else {
            $this->uri = [];
        }
        return $this->uri;
    }
    
    /**
     * Procesa la URL y ejecuta el controlador/método correspondiente
     */
    private function dispatch() {
        $this->filter_url();
        
        // Determinar el controlador
        $current_controller = $this->uri[0] ?? DEFAULT_CONTROLLER;

        // Alias: "estado" redirige a "estados"
        if($current_controller === 'index') {
            $current_controller = DEFAULT_CONTROLLER;
        }
        if($current_controller === 'estado') {
            $current_controller = 'estados';
        }

        unset($this->uri[0]);

        $controller = $current_controller . 'Controller';

        if(!class_exists($controller)) {
            $current_controller = DEFAULT_ERROR_CONTROLLER;
            $controller = DEFAULT_ERROR_CONTROLLER . 'Controller';
        }

        // Determinar el método
        $current_method = $this->uri[1] ?? DEFAULT_METHOD;

        if(isset($this->uri[1])) {
            $method = str_replace('-', '_', $this->uri[1]);
            if(!method_exists($controller, $method)) {
                $current_controller = DEFAULT_ERROR_CONTROLLER;
                $controller = DEFAULT_ERROR_CONTROLLER . 'Controller';
                $current_method = DEFAULT_METHOD;
            } else {
                $current_method = $method;
            }
            unset($this->uri[1]);
        }

        // Definir constantes globales
        define('CONTROLLER', $current_controller);
        define('METHOD', $current_method);

        // Instanciar y ejecutar
        $instance = new $controller;
        $params = array_values(empty($this->uri) ? [] : $this->uri);

        if(empty($params)) {
            call_user_func([$instance, $current_method]);
        } else {
            call_user_func_array([$instance, $current_method], $params);
        }
    }

    // Método estático para iniciar el Core
    public static function run() {
        new self();
    }
}

?>

