<?php

// Clase helper para funcionalidades específicas del todo list
class Todo {
    
    // Suponiendo que la conexión PDO está disponible a través de una clase Db estática
    // y que los IDs de estado son: 1=Pendiente, 3=Completada
    
    /**
     * Obtener estadísticas de tareas
     * @return array Array con estadísticas
     */
    public static function getStats() {
        // En lugar de 'completed = 1', usamos el ID del estado 'Completada' (asumimos 3)
        // En lugar de 'completed = 0', usamos el ID del estado 'Pendiente' (asumimos 1)
        $result = Db::query("
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN id_estado = 3 THEN 1 ELSE 0 END) as completed, 
                SUM(CASE WHEN id_estado = 1 THEN 1 ELSE 0 END) as pending
            FROM todos
        ");
        return $result->fetch();
    }
    
    /**
     * Obtener tareas por ID de Prioridad
     * @param int $id_prioridad ID de la prioridad (de la tabla 'prioridades')
     * @return array Array de tareas
     */
    public static function getByPriorityId($id_prioridad) {
        // La columna ahora es id_prioridad
        $sql = "
            SELECT 
                t.*, 
                e.nombre_estado, 
                p.nombre_prioridad
            FROM todos t
            INNER JOIN estados e ON t.id_estado = e.id_estado
            INNER JOIN prioridades p ON t.id_prioridad = p.id_prioridad
            WHERE t.id_prioridad = ? 
            ORDER BY t.created_at DESC
        ";
        $result = Db::query($sql, [$id_prioridad]);
        return $result->fetchAll();
    }
    
    /**
     * Cambiar el estado de completado/pendiente de una tarea
     * @param int $id ID de la tarea
     * @return bool True si se cambió exitosamente
     */
    // classes/Todo.php
public static function toggleStatus($id) {
    // Si es Pendiente (1), cambia a Completada (3); si no, cambia a Pendiente (1)
    $sql = "UPDATE todos SET id_estado = (CASE id_estado WHEN 1 THEN 3 ELSE 1 END) WHERE id = ?";
    Db::query($sql, [$id]);
    return true;
}
    
    // --- Métodos de Presentación (No necesitan JOIN si ya obtuviste los nombres ---
    
    /**
     * Obtener el texto de prioridad en español (usando el nombre_prioridad guardado en la BD)
     * @param string $priorityName Nombre de la prioridad (low, medium, high)
     * @return string Prioridad en español
     */
    public static function getPriorityText($priorityName) {
        $priorities = [
            'low' => 'Baja',
            'medium' => 'Media',
            'high' => 'Alta'
        ];
        // Aquí usarías el nombre que viene de la tabla 'prioridades' (ej: 'low')
        return $priorities[$priorityName] ?? 'Media'; 
    }
    
    /**
     * Obtener el color de Bootstrap para la prioridad
     * @param string $priorityName Nombre de la prioridad
     * @return string Clase CSS de Bootstrap
     */
    public static function getPriorityColor($priorityName) {
        $colors = [
            'low' => 'success',    // Verde
            'medium' => 'warning', // Amarillo
            'high' => 'danger'     // Rojo
        ];
        return $colors[$priorityName] ?? 'secondary';
    }
}
?>
