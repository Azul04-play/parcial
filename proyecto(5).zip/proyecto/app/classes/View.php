<?php

class View {

    public static function render($view, $data = []) {

        $d = to_Object($data);

        $file = VIEWS . CONTROLLER . DS . $view . '.php';

        if (is_file($file)) {
            require_once $file;
        } else {
            // Cargar la vista de error 404 REAL
            require_once VIEWS . 'error' . DS . '404View.php';
        }
    }
}
