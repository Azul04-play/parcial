<?php

class estadosController extends Controller {

    protected $title = 'estados';

    /**
     * Mostrar todos los estados
     */
    function index() {
        $estados = estadosModel::all();

        $data = [
            'page_title' => 'Lista de Estados',
            'estados' => $estados
        ];

         View::render('list', [
    'estados' => $estados,
]);

    }

    /**
     * Mostrar formulario para crear un estado
     */
    function create() {
        $data = [
            'page_title' => 'Nuevo Estado'
        ];

        View::render('estados/create', $data);
    }

    /**
     * Guardar un nuevo estado
     */
    function store() {
        if (!$this->validatePost(['nombre_estado'])) {
            $this->redirectWithMessage('estados/create', 'Debe ingresar el nombre del estado', 'warning');
            return;
        }

        $estadoData = [
            'nombre_estado' => trim($_POST['nombre_estado']),
            'descripcion' => trim($_POST['descripcion'] ?? '')
        ];

        estadosModel::create($estadoData);

        $this->redirectWithMessage('estados', 'Estado creado correctamente', 'success');
    }
     /**
     * Editar un estado
     */
    function edit() {
        $id = $_GET['id'] ?? null;
        if (!$id || !is_numeric($id)) {
            $this->redirectWithMessage('estados', 'ID inválido', 'danger');
            return;
        }

        $estado = estadosModel::find($id);


        if (!$estado) {
            $this->redirectWithMessage('estados', 'Estado no encontrado', 'danger');
            return;
        }

        View::render('estados/edit', [
            'page_title' => 'Editar Estado',
            'estado' => $estado
        ]);
    }
        /**
     * Actualizar estado
     */
    function update() {
        if (!$this->validatePost(['id_estado', 'nombre_estado'])) {
            $this->redirectWithMessage('estados', 'Datos incompletos', 'warning');
            return;
        }

        $id = $_POST['id_estado'];
        $estado = estadosModel::findEstado($id);
        if (!$estado) {
            $this->redirectWithMessage('estados', 'Estado no encontrado', 'danger');
            return;
        }

        $data = [
            'nombre_estado' => trim($_POST['nombre_estado']),
            'descripcion' => trim($_POST['descripcion'] ?? '')
        ];

      estadosModel::updateEstado($id, $data);


        $this->redirectWithMessage('estados', 'Estado actualizado correctamente', 'success');
    }

    /**
     * Eliminar estado
     */
    function delete() {
        $id = $_GET['id'] ?? null;
        if (!$id || !is_numeric($id)) {
            $this->redirectWithMessage('estados', 'ID inválido', 'danger');
            return;
        }

        $estado = estadosModel::find($id);


        if (!$estado) {
            $this->redirectWithMessage('estados', 'Estado no encontrado', 'danger');
            return;
        }

        estadosModel::deleteEstado($id);

        $this->redirectWithMessage('estados', 'Estado eliminado correctamente', 'info');
    }

    /**
     * Buscar estado por nombre
     */
    function search() {
        $search = $_GET['q'] ?? '';
        if (empty($search)) {
            $this->redirectWithMessage('estados', 'Ingrese un término de búsqueda', 'warning');
            return;
        }

        $estados = estadosModel::search($search);

        View::render('estados/list', [
            'page_title' => "Resultados para: $search",
            'estados' => $estados,
            'search_term' => $search
        ]);
    }


}
?>
