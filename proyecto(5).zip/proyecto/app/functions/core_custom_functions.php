<?php 

// Primera función de prueba custom
function en_custom() {
  return 'RETORNO DE LA FUNCION EN_CUSTOM.';
}