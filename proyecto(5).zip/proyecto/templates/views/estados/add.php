<?php require_once INCLUDES . 'inc_header.php'; ?>

<!-- Mostrar notificaciones toast -->
<?= Toast::flash() ?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow-lg">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">
                    <i class="fas fa-plus-circle me-2"></i> <?= $data['page_title'] ?? 'Agregar Nuevo Estado' ?>
                </h4>
            </div>
            <div class="card-body">
                <form method="POST" action="<?= URL ?>estado/store">
                    
                    <div class="mb-4">
                        <label for="nombre_estado" class="form-label fw-bold">Nombre del Estado *</label>
                        <input type="text" class="form-control form-control-lg" id="nombre_estado" name="nombre_estado" 
                               placeholder="Ej: En Revisión, Bloqueado, Pendiente" required>
                        <div class="form-text">
                            Introduce un nombre descriptivo para el nuevo estado de tarea.
                        </div>
                    </div>
                    
                    <div class="d-flex justify-content-between pt-3 border-top">
                        <!-- Botón para volver a la lista de estados -->
                        <a href="<?= URL ?>estado" class="btn btn-outline-secondary">
                             <i class="fas fa-arrow-left me-1"></i> Volver a la Lista
                        </a>
                        <!-- Botón de guardar -->
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-save me-1"></i> Guardar Estado
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once INCLUDES . 'inc_footer.php'; ?>