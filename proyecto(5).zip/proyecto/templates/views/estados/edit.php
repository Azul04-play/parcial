<?php require_once INCLUDES . 'inc_header.php'; ?>

<!-- Mostrar notificaciones toast -->
<?= Toast::flash() ?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow-lg">
            <div class="card-header bg-warning text-dark">
                <h4 class="mb-0">
                    <i class="fas fa-edit me-2"></i> <?= $data['page_title'] ?? 'Editar Estado' ?>
                </h4>
            </div>
            <div class="card-body">
                <?php $estado = $data['estado']; ?>
                <form method="POST" action="<?= URL ?>estados/update">
                    <!-- ID Oculto del Estado -->
                    <input type="hidden" name="id_estado" value="<?= $estado['id_estado'] ?>">

                    <div class="mb-4">
                        <label for="nombre_estado" class="form-label fw-bold">Nombre del Estado *</label>
                        <input type="text" class="form-control form-control-lg" id="nombre_estado" name="nombre_estado" 
                               value="<?= htmlspecialchars($estado['nombre_estado']) ?>" required>
                        <div class="form-text">
                            Modifica el nombre de este estado (ID: <?= $estado['id_estado'] ?>).
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="descripcion" class="form-label">Descripción</label>
                        <textarea class="form-control" id="descripcion" name="descripcion" rows="3"><?= htmlspecialchars($estado['descripcion']) ?></textarea>
                        <div class="form-text">
                            Agrega o modifica la descripción del estado.
                        </div>
                    </div>

                    <div class="d-flex justify-content-between pt-3 border-top">
                        <!-- Botón para volver a la lista de estados -->
                        <a href="<?= URL ?>estados" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left me-1"></i> Cancelar
                        </a>
                        <!-- Botón de actualizar -->
                        <button type="submit" class="btn btn-warning text-dark">
                            <i class="fas fa-sync-alt me-1"></i> Actualizar Estado
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once INCLUDES . 'inc_footer.php'; ?>
