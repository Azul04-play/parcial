<?php require_once INCLUDES . 'inc_header.php'; ?>

<!-- Mostrar notificaciones toast -->
<?= Toast::flash() ?>

<div class="row justify-content-center">
    <div class="col-md-10">
        <h1 class="mb-4 d-flex justify-content-between align-items-center">
            <?= $data['page_title'] ?? 'Gestión de Estados' ?>
            <!-- Botón de navegación al formulario CREATE -->
            <a href="<?= URL ?>estados/create" class="btn btn-primary">
                + Nuevo Estado
            </a>
        </h1>

        <div class="card shadow-sm">
            <div class="card-header bg-light">
                <h5 class="mb-0">Lista de Estados Disponibles</h5>
            </div>
            <div class="card-body p-0">
                <?php if (!empty($data['estados'])): ?>
                    <ul class="list-group list-group-flush">
                        <?php foreach ($data['estados'] as $estado): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <span class="fw-bold me-2">ID <?= $estado['id_estado'] ?>:</span>
                                    <?= htmlspecialchars($estado['nombre_estado']) ?>

                                    <?php if ($estado['id_estado'] == 1): ?>
                                        <small class="text-info">(Por defecto: Pendiente)</small>
                                    <?php elseif ($estado['id_estado'] == 3): ?>
                                        <small class="text-success">(Por defecto: Completada)</small>
                                    <?php endif; ?>
                                </div>
                                <div class="btn-group" role="group">
                                    <!-- Botón para Editar -->
                                    <a href="<?= URL ?>estados/edit?id=<?= $estado['id_estado'] ?>" 
                                       class="btn btn-sm btn-outline-primary" title="Editar">
                                       <i class="fas fa-edit"></i> Editar
                                    </a>
                                    <!-- Botón Editar -->
<a href="<?= URL ?>estados/edit?id=<?= $estado['id_estado'] ?>" class="btn btn-sm btn-outline-primary">Editar</a>
                                    <!-- Botón para Eliminar -->
                                    <a href="<?= URL ?>estados/delete?id=<?= $estado['id_estado'] ?>" 
                                       class="btn btn-sm btn-outline-danger" title="Eliminar"
                                       onclick="return confirm('¿Eliminar el estado \'<?= htmlspecialchars($estado['nombre_estado']) ?>\'? Esto podría afectar tareas existentes.')">
                                       <i class="fas fa-trash-alt"></i> Eliminar
                                    </a>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <div class="text-center text-muted py-5">
                        <i class="fas fa-exclamation-triangle fa-3x mb-3"></i>
                        <h5>No hay estados definidos</h5>
                        <p>Asegúrate de tener al menos los estados "Pendiente" y "Completada".</p>
                        <a href="<?= URL ?>estados/create" class="btn btn-primary">
                            Crear Primer Estado
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once INCLUDES . 'inc_footer.php'; ?>
