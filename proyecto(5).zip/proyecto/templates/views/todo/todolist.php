<?php require_once INCLUDES . 'inc_header.php'; ?>

<!-- Mostrar notificaciones toast -->
<?= Toast::flash() ?>

<div class="row">
    <div class="col-md-8">
        <h1 class="mb-4">
            <?= $data['page_title'] ?? 'Mi Lista de Tareas' ?>
        </h1>
        
        <!-- Barra de búsqueda -->
        <div class="mb-4">
            <form method="GET" action="<?= URL ?>todo/search" class="d-flex">
                <input type="text" class="form-control me-2" name="q" 
                        placeholder="Buscar tareas..." value="<?= $data['search_term'] ?? '' ?>">
                <button type="submit" class="btn btn-outline-secondary">Buscar</button>
            </form>
        </div>

        <!-- LISTA DE TAREAS -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Tareas</h5>
            </div>
            <div class="card-body p-0">
                <?php if (!empty($data['todos'])): ?>
                    <?php foreach ($data['todos'] as $todo): 
                        // Lógica para estado y prioridad (asumiendo 3 es Completada)
                        $is_completed = ($todo['id_estado'] == 3);
                    ?>
                        <div class="todo-item p-3 border-bottom <?= $is_completed ? 'completed-task' : '' ?>">
                            <div class="d-flex align-items-start">
                                <div class="flex-grow-1">
                                    <div class="d-flex align-items-center mb-2">
                                        <h6 class="mb-0 me-2 <?= $is_completed ? 'text-decoration-line-through text-muted' : '' ?>">
                                            <?= htmlspecialchars($todo['task']) ?>
                                        </h6>
                                        <span class="badge priority-badge bg-<?= $todo['priority_color'] ?>">
                                            <?= $todo['priority_text'] ?>
                                        </span>
                                        <!-- Mostrar el nombre del estado (si lo trajiste con el JOIN) -->
                                        <?php if (isset($todo['nombre_estado'])): ?>
                                            <span class="badge bg-secondary ms-2"><?= $todo['nombre_estado'] ?></span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <?php if ($todo['description']): ?>
                                        <p class="text-muted mb-2 small">
                                            <?= htmlspecialchars($todo['description']) ?>
                                        </p>
                                    <?php endif; ?>
                                    
                                    <small class="text-muted">
                                        <?= $todo['formatted_date'] ?>
                                    </small>
                                </div>
                                
                                <div class="d-flex gap-2">
                                    <!-- Botones de acción... -->
                                    <a href="<?= URL ?>todo/edit?id=<?= $todo['id'] ?>" 
                                       class="btn btn-sm btn-outline-primary">Editar</a>
                                    <!-- Eliminado el alert() -->
                                    <a href="<?= URL ?>todo/delete?id=<?= $todo['id'] ?>" 
                                       class="btn btn-sm btn-outline-danger"
                                       onclick="return confirm('¿Eliminar esta tarea?')">Eliminar</a>
                                    <a href="<?= URL ?>todo/toggle?id=<?= $todo['id'] ?>" 
                                       class="btn btn-sm <?= $is_completed ? 'btn-outline-success' : 'btn-success' ?>">
                                        <?= $is_completed ? 'Pendiente' : 'Completar' ?>
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="text-center text-muted py-5">
                        <i class="fas fa-clipboard-list fa-3x mb-3"></i>
                        <h5>No hay tareas</h5>
                        <!-- Mensajes de no hay tareas... -->
                        <p>
                            <?php if (isset($data['search_term'])): ?>
                                No se encontraron tareas para "<?= htmlspecialchars($data['search_term']) ?>"
                            <?php else: ?>
                                ¡Agrega tu primera tarea!
                            <?php endif; ?>
                        </p>
                        <a href="<?= URL ?>todo/add" class="btn btn-primary">
                            Nueva Tarea
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
    <form method="GET" action="<?= URL ?>todo">
        <!-- Filtro por Prioridad -->
        <h6>Filtrar por Prioridad</h6>
        <?php $prioridad = $data['current_filters']['filter_prioridad'] ?? null; ?>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="filter_prioridad" value="1" id="priority_low"
                <?= ($prioridad == 1) ? 'checked' : '' ?>>
            <label class="form-check-label" for="priority_low">Baja</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="filter_prioridad" value="2" id="priority_medium"
                <?= ($prioridad == 2) ? 'checked' : '' ?>>
            <label class="form-check-label" for="priority_medium">Media</label>
        </div>
        <div class="form-check mb-3">
            <input class="form-check-input" type="radio" name="filter_prioridad" value="3" id="priority_high"
                <?= ($prioridad == 3) ? 'checked' : '' ?>>
            <label class="form-check-label" for="priority_high">Alta</label>
        </div>

        <!-- Filtro por Estado -->
        <h6>Filtrar por Estado</h6>
        <?php $estado = $data['current_filters']['filter_estado'] ?? null; ?>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="filter_estado" value="0" id="estado_pendiente"
                <?= ($estado === '0') ? 'checked' : '' ?>>
            <label class="form-check-label" for="estado_pendiente">Pendiente</label>
        </div>
        <div class="form-check mb-3">
            <input class="form-check-input" type="radio" name="filter_estado" value="1" id="estado_completado"
                <?= ($estado == 1) ? 'checked' : '' ?>>
            <label class="form-check-label" for="estado_completado">Completado</label>
        </div>

        <div class="d-flex justify-content-between">
            <button type="submit" class="btn btn-sm btn-dark">Aplicar Filtros</button>
            <a href="<?= URL ?>todo" class="btn btn-sm btn-outline-danger">Limpiar</a>
        </div>
    </form>
</div>


        <!-- Fin de Panel de Filtros -->

        <!-- Panel lateral existente -->
        <div class="card">
            <div class="card-body">
                <h5 class="mb-3">Sistema de Tareas</h5>
                <p class="text-muted mb-4">
                    Organiza tus actividades diarias de forma simple.
                </p>
                <a href="<?= URL ?>todo/add" class="btn btn-primary w-100">
                    Nueva Tarea
                </a>
            </div>
        </div>
    </div>
</div>

<?php require_once INCLUDES . 'inc_footer.php'; ?>