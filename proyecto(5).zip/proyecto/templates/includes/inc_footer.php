<!-- inc_footer.php -->
<!-- scripts -->

<!-- jQuery: Librería JavaScript esencial para manipulación del DOM, eventos y AJAX -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<!-- Bootstrap JS: Funcionalidades interactivas de Bootstrap 5 (modals, carousels, etc.) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
